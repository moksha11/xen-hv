#define INTEGER_ONLY
#include "vscanf.c"
