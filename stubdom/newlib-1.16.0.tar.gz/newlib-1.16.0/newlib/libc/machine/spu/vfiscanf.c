#define INTEGER_ONLY
#include "vfscanf.c"
