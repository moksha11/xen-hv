#define INTEGER_ONLY
#include "vfprintf.c"
