#ifndef _SYS_SCHED_H
#define _SYS_SCHED_H

int sched_yield(void);

#endif
